#!/bin/sh

java  -jar genRob.genMediator.jar

