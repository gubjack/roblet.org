#!/bin/sh

if [ -z "$1" ]; then echo "Server port missing"; exit; fi
if [ -z "$2" ]; then echo "Gate port missing"; exit; fi
if [ -z "$3" ]; then echo "Target server name missing"; exit; fi

cp="genRob.genControl.jar:genRob.genGate.jar"
dp="genRob.genControl.port=$1"
ec="genRob.genGate.ModuleImpl"
gp="genRob.genGate.port=$2"
gg="genRob.genGate.target=$3"

java  -classpath $cp  -D$dp  -D$gp  -D$gg  genRob.genControl.Main  $ec
