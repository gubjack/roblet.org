#!/bin/sh

#  Dies ist eine Beispiel-Start-Datei fuer den Roblet(R)-Server.
#  ISO-8859-1

#  Er wird hier ohne weitere Module an Port 2001 mit aktivierten
#  Sicherheitsmerkmalen gestartet - und stellt daher nur
#  Standardfunktionalitaet bereit.
#  Mehr Dokumentation ist via  index.html  zu erhalten.

security=-DgenRob.genControl.security=true
port=-DgenRob.genControl.port=2001
java  $security  $port  -jar genRob.genControl.jar

#  Fuer ein Beispiel mit Modul siehe Dokumenation.
