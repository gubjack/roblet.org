#!/bin/sh

java  -jar org.roblet.jar  directory

