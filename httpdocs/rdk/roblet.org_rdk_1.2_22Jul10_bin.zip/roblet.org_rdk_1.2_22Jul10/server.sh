#!/bin/sh

#  Dies ist eine Beispiel-Start-Datei fuer den Roblet(R)-Server.
#  ISO-8859-1

#  Er wird hier ohne weitere Module gestartet - und stellt daher nur
#  Standardfunktionalitaet bereit.
#  Mehr Dokumentation ist via  index.html  zu erhalten.

java  -jar org.roblet.jar  server

#  Fuer ein Beispiel mit Modul siehe Dokumenation.
