#!/bin/sh

sp=java.security.policy=browser.policy
cb=java.rmi.server.codebase=http://localhost:8080/jini-examples-dl.jar

java  -D$sp  -D$cb  -jar org.roblet.jar  browser
